<div class="footer bg-dark mt-5" style="height: 50px; width: 100%; line-height: 20px;">
	<div class="pt-3">
		<strong class="text-left ml-4 text-white">Copyright<i class="fas fa-fw fa-copyright"></i> <?= date('Y'); ?><a href="https://irsyadproject.blogspot.com/" target="_blank" class="text-warning text-decoration-none"> Irsyad Project</a></strong>
		<strong class="float-right mr-3 text-warning"><i class="fas fa-fw fa-code text-white"></i> Si <span class="text-danger">Prediksi </span>V.1</strong>
	</div>
</div>
</body>
</html>