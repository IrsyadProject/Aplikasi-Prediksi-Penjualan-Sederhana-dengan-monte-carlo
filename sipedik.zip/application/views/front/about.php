<div class="container tada animated">
	<div class="row mt-3">
		<div class="col-md">
			<div class="card border-dark">
				<div class="card-header bg-dark text-white text-center">
					<i class="fas fa-fw fa-id-card"></i> TENTANG
				</div>
				<div class="card-body text-center">
					<div class="row mb-2 justify-content-center">
						<div class="col-md-10">
							Aplikasi dengan Nama Si Prediksi Versi 1 ini dibuat untuk memenuhi tugas mata kuliah simulasi dan pemodelan. yang fungsi dari aplikasi ini adalah untuk memprediksi penjualan dengan menggunakan metode monte carlo.
						</div>
					</div>
					<div class="card-deck">
					  <div class="card border-dark">
					    <div class="card-body">
					      <!-- 16:9 aspect ratio -->
							<div class="embed-responsive embed-responsive-4by3">
							  <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Bc2ohFxgrvY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							</div>
					    </div>
					    <div class="card-footer bg-dark text-white">
					      <small class="text-white"><?= date('l, d F Y'); ?></small>
					    </div>
					  </div>
					  <div class="card border-dark">
					    <div class="card-body">
					      <div class="embed-responsive embed-responsive-4by3">
								<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/CppsEFT6HCA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							</div>
					    </div>
					    <div class="card-footer bg-dark text-white">
					      <small class="text-white"><?= date('l, d F Y'); ?></small>
					    </div>
					  </div>
					  <div class="card border-dark">
					    <div class="card-body">
					      <div class="embed-responsive embed-responsive-4by3">
					      	<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/M65yJI5ui9M" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					      </div>
					    </div>
					    <div class="card-footer bg-dark text-white">
					      <small class="text-white"><?= date('l, d F Y'); ?></small>
					    </div>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>